# ClassIA - Front-end

Protótipo funcional em React + TypeScript para o trabalho de Tecnologias Emergentes.

## Tecnologias
- React
- TypeScript
- Vite
- React Router
- Lucide React
- CSS puro
- Dados mockados

## Como executar no VS Code

1. Extraia a pasta.
2. Abra a pasta `classia-react` no VS Code.
3. Abra o terminal do VS Code.
4. Execute:

```bash
npm install
npm run dev
```

5. Abra o endereço mostrado pelo Vite (normalmente `http://localhost:5173`).

## Login de demonstração

A tela de login possui um seletor:
- Coordenação
- Professor
- Aluno

O e-mail e a senha são apenas visuais neste protótipo. Basta escolher o perfil e clicar em **Entrar**.

## Próxima etapa

Quando o back-end em Java + Spring Boot estiver pronto, os dados mockados em `src/data/mock.ts` podem ser substituídos por chamadas HTTP à API REST.
