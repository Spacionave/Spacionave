import { Navigate, Route, Routes } from 'react-router-dom'
import Login from './pages/Login'
import DashboardAdmin from './pages/admin/DashboardAdmin'
import Alunos from './pages/admin/Alunos'
import NovoAluno from './pages/admin/NovoAluno'
import Professores from './pages/admin/Professores'
import Disciplinas from './pages/admin/Disciplinas'
import Turmas from './pages/admin/Turmas'
import DashboardProfessor from './pages/professor/DashboardProfessor'
import LancamentoNotas from './pages/professor/LancamentoNotas'
import LancamentoFaltas from './pages/professor/LancamentoFaltas'
import AnaliseAluno from './pages/professor/AnaliseAluno'
import DashboardAluno from './pages/aluno/DashboardAluno'
import MinhasNotas from './pages/aluno/MinhasNotas'
import MinhaFrequencia from './pages/aluno/MinhaFrequencia'
import MeuDesempenho from './pages/aluno/MeuDesempenho'
import AnaliseIA from './pages/aluno/AnaliseIA'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />

      <Route path="/admin" element={<DashboardAdmin />} />
      <Route path="/admin/alunos" element={<Alunos />} />
      <Route path="/admin/alunos/novo" element={<NovoAluno />} />
      <Route path="/admin/professores" element={<Professores />} />
      <Route path="/admin/disciplinas" element={<Disciplinas />} />
      <Route path="/admin/turmas" element={<Turmas />} />

      <Route path="/professor" element={<DashboardProfessor />} />
      <Route path="/professor/notas" element={<LancamentoNotas />} />
      <Route path="/professor/faltas" element={<LancamentoFaltas />} />
      <Route path="/professor/analise" element={<AnaliseAluno />} />

      <Route path="/aluno" element={<DashboardAluno />} />
      <Route path="/aluno/notas" element={<MinhasNotas />} />
      <Route path="/aluno/frequencia" element={<MinhaFrequencia />} />
      <Route path="/aluno/desempenho" element={<MeuDesempenho />} />
      <Route path="/aluno/ia" element={<AnaliseIA />} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
