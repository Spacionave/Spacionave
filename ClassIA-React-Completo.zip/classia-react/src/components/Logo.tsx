import { GraduationCap } from 'lucide-react'

export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <div className={`logo-inline ${light ? 'light' : ''}`}>
      <span className="logo-mark"><GraduationCap size={24} /></span>
      <strong>ClassIA</strong>
    </div>
  )
}
