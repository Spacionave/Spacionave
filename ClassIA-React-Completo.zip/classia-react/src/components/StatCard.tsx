import type { ReactNode } from 'react'

type Props = {
  label: string
  value: string | number
  icon?: ReactNode
  tone?: 'blue' | 'green' | 'orange' | 'purple'
}

export default function StatCard({ label, value, icon, tone = 'blue' }: Props) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}>{icon}</div>
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
    </div>
  )
}
