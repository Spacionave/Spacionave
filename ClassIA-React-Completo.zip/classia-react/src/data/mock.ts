export const alunos = [
  { nome: 'João Silva', ra: '2026001', turma: 'ADS 3A', situacao: 'Regular' },
  { nome: 'Maria Souza', ra: '2026002', turma: 'ADS 3A', situacao: 'Atenção' },
  { nome: 'Lucas Lima', ra: '2026003', turma: 'ADS 3B', situacao: 'Regular' },
  { nome: 'Ana Beatriz', ra: '2026004', turma: 'ADS 3A', situacao: 'Regular' },
  { nome: 'Carlos Henrique', ra: '2026005', turma: 'ADS 3B', situacao: 'Atenção' },
]

export const professores = [
  { nome: 'Carlos Souza', email: 'carlos@classia.com', disciplina: 'Banco de Dados', turma: 'ADS 3A' },
  { nome: 'Ana Lima', email: 'ana@classia.com', disciplina: 'Engenharia de Software', turma: 'ADS 3B' },
  { nome: 'Marcos Silva', email: 'marcos@classia.com', disciplina: 'Programação Web', turma: 'ADS 3A' },
  { nome: 'Juliana Rocha', email: 'juliana@classia.com', disciplina: 'Redes de Computadores', turma: 'ADS 3B' },
]

export const disciplinas = [
  { nome: 'Banco de Dados', codigo: 'BD001', carga: '80h', professor: 'Carlos Souza' },
  { nome: 'Engenharia de Software', codigo: 'ES001', carga: '80h', professor: 'Ana Lima' },
  { nome: 'Programação Web', codigo: 'PW001', carga: '80h', professor: 'Marcos Silva' },
  { nome: 'Redes de Computadores', codigo: 'RC001', carga: '80h', professor: 'Juliana Rocha' },
]

export const notas = [
  { disciplina: 'Banco de Dados', p1: 8.0, p2: 7.5, media: 7.75 },
  { disciplina: 'Engenharia de Software', p1: 6.0, p2: 5.5, media: 5.75 },
  { disciplina: 'Programação Web', p1: 9.0, p2: 8.0, media: 8.5 },
  { disciplina: 'Redes de Computadores', p1: 7.0, p2: 7.0, media: 7.0 },
]

export const frequencias = [
  { disciplina: 'Banco de Dados', percentual: 92 },
  { disciplina: 'Engenharia de Software', percentual: 78 },
  { disciplina: 'Programação Web', percentual: 84 },
  { disciplina: 'Redes de Computadores', percentual: 74 },
]
