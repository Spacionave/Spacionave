import type { ReactNode } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  BarChart3,
  BookOpen,
  Bot,
  ClipboardCheck,
  Gauge,
  GraduationCap,
  LogOut,
  School,
  User,
  Users,
} from 'lucide-react'
import Logo from '../components/Logo'

type Role = 'admin' | 'professor' | 'aluno'

type Item = { label: string; to: string; icon: ReactNode }

const menus: Record<Role, Item[]> = {
  admin: [
    { label: 'Dashboard', to: '/admin', icon: <Gauge size={18} /> },
    { label: 'Alunos', to: '/admin/alunos', icon: <Users size={18} /> },
    { label: 'Professores', to: '/admin/professores', icon: <User size={18} /> },
    { label: 'Turmas', to: '/admin/turmas', icon: <School size={18} /> },
    { label: 'Disciplinas', to: '/admin/disciplinas', icon: <BookOpen size={18} /> },
  ],
  professor: [
    { label: 'Dashboard', to: '/professor', icon: <Gauge size={18} /> },
    { label: 'Notas', to: '/professor/notas', icon: <BarChart3 size={18} /> },
    { label: 'Faltas', to: '/professor/faltas', icon: <ClipboardCheck size={18} /> },
    { label: 'Análise dos alunos', to: '/professor/analise', icon: <Bot size={18} /> },
  ],
  aluno: [
    { label: 'Início', to: '/aluno', icon: <Gauge size={18} /> },
    { label: 'Minhas notas', to: '/aluno/notas', icon: <BarChart3 size={18} /> },
    { label: 'Minha frequência', to: '/aluno/frequencia', icon: <ClipboardCheck size={18} /> },
    { label: 'Meu desempenho', to: '/aluno/desempenho', icon: <GraduationCap size={18} /> },
    { label: 'Análise IA', to: '/aluno/ia', icon: <Bot size={18} /> },
  ],
}

const roleLabels = {
  admin: ['Coordenação', 'Administrador'],
  professor: ['Prof. João', 'Professor'],
  aluno: ['João Silva', 'Aluno'],
}

export default function DashboardLayout({
  role,
  title,
  subtitle,
  children,
}: {
  role: Role
  title: string
  subtitle?: string
  children: ReactNode
}) {
  const location = useLocation()
  const [name, roleName] = roleLabels[role]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><Logo light /></div>

        <nav className="sidebar-nav">
          {menus[role].map((item) => {
            const active = location.pathname === item.to
            return (
              <Link key={item.to} to={item.to} className={active ? 'nav-item active' : 'nav-item'}>
                {item.icon}
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>

        <Link className="nav-item logout" to="/">
          <LogOut size={18} />
          <span>Sair</span>
        </Link>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="page-heading">
            <h1>{title}</h1>
            {subtitle && <p>{subtitle}</p>}
          </div>

          <div className="top-user">
            <div className="avatar">{name.charAt(0)}</div>
            <div>
              <strong>{name}</strong>
              <span>{roleName}</span>
            </div>
          </div>
        </header>

        <div className="page-content">{children}</div>
      </main>
    </div>
  )
}
