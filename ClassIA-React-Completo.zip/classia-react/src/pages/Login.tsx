import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, LockKeyhole, Mail } from 'lucide-react'
import Logo from '../components/Logo'

export default function Login() {
  const navigate = useNavigate()
  const [perfil, setPerfil] = useState('admin')

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    navigate(`/${perfil}`)
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-brand">
          <Logo light />
          <h1>Gestão Acadêmica Inteligente</h1>
          <p>Mais que notas, mais oportunidades.</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <label>
            E-mail
            <div className="input-icon">
              <Mail size={18} />
              <input type="email" placeholder="seu@email.com" defaultValue="admin@classia.com" />
            </div>
          </label>

          <label>
            Senha
            <div className="input-icon">
              <LockKeyhole size={18} />
              <input type="password" placeholder="Sua senha" defaultValue="123456" />
              <Eye size={18} className="input-right-icon" />
            </div>
          </label>

          <label>
            Perfil de demonstração
            <select value={perfil} onChange={(e) => setPerfil(e.target.value)}>
              <option value="admin">Coordenação</option>
              <option value="professor">Professor</option>
              <option value="aluno">Aluno</option>
            </select>
          </label>

          <button className="btn btn-primary btn-full" type="submit">Entrar</button>
        </form>

        <button className="link-button">Esqueci minha senha</button>
      </div>

      <div className="login-side">
        <div className="hero-chip">Tecnologia + Educação</div>
        <h2>Decisões acadêmicas apoiadas por dados e Inteligência Artificial.</h2>
        <p>
          Acompanhe notas, frequência, turmas e indicadores de desempenho em um único ambiente.
        </p>
        <div className="hero-grid">
          <div><strong>425</strong><span>alunos</span></div>
          <div><strong>32</strong><span>professores</span></div>
          <div><strong>18</strong><span>turmas</span></div>
        </div>
      </div>
    </div>
  )
}
