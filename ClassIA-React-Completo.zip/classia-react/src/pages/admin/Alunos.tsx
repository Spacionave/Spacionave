import { Eye, Pencil, Plus, Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import DashboardLayout from '../../layouts/DashboardLayout'
import { alunos } from '../../data/mock'

export default function Alunos() {
  return (
    <DashboardLayout role="admin" title="Alunos" subtitle="Gerencie os alunos cadastrados no sistema.">
      <section className="panel">
        <div className="toolbar">
          <div className="search-box">
            <Search size={18} />
            <input placeholder="Buscar por nome, RA ou turma..." />
          </div>
          <Link to="/admin/alunos/novo" className="btn btn-primary"><Plus size={18} /> Novo aluno</Link>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Nome</th><th>RA</th><th>Turma</th><th>Situação</th><th>Ações</th></tr>
            </thead>
            <tbody>
              {alunos.map((aluno) => (
                <tr key={aluno.ra}>
                  <td><strong>{aluno.nome}</strong></td>
                  <td>{aluno.ra}</td>
                  <td>{aluno.turma}</td>
                  <td><span className={`badge ${aluno.situacao === 'Regular' ? 'success' : 'warning'}`}>{aluno.situacao}</span></td>
                  <td className="actions">
                    <button title="Visualizar"><Eye size={16} /></button>
                    <button title="Editar"><Pencil size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  )
}
