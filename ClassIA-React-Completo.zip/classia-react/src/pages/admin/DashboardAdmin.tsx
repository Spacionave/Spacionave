import { AlertTriangle, BookOpen, Bot, School, UserRound, Users } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'
import StatCard from '../../components/StatCard'

export default function DashboardAdmin() {
  return (
    <DashboardLayout role="admin" title="Olá, Coordenação! 👋" subtitle="Aqui está um resumo do ambiente acadêmico.">
      <div className="stats-grid">
        <StatCard label="Alunos" value="425" icon={<Users size={22} />} />
        <StatCard label="Professores" value="32" icon={<UserRound size={22} />} tone="purple" />
        <StatCard label="Turmas" value="18" icon={<School size={22} />} tone="green" />
        <StatCard label="Disciplinas" value="24" icon={<BookOpen size={22} />} tone="orange" />
      </div>

      <section className="panel">
        <div className="section-title">
          <div>
            <h2>Indicadores acadêmicos</h2>
            <p>Acompanhamento geral da instituição.</p>
          </div>
        </div>

        <div className="indicator-grid">
          <div className="indicator-card danger">
            <AlertTriangle size={22} />
            <span>Alunos com média abaixo de 6</span>
            <strong>28</strong>
          </div>
          <div className="indicator-card warning">
            <AlertTriangle size={22} />
            <span>Frequência abaixo de 75%</span>
            <strong>14</strong>
          </div>
          <div className="indicator-card warning">
            <Users size={22} />
            <span>Alunos em situação de atenção</span>
            <strong>35</strong>
          </div>
        </div>
      </section>

      <div className="two-col">
        <section className="panel">
          <div className="section-title">
            <div>
              <h2>Desempenho geral dos alunos</h2>
              <p>Média consolidada por período.</p>
            </div>
          </div>
          <div className="fake-chart">
            {[72, 58, 66, 80, 74, 64, 83, 55, 68, 49].map((v, i) => (
              <div key={i} className="bar-wrap">
                <div className="bar" style={{ height: `${v}%` }} />
              </div>
            ))}
          </div>
        </section>

        <section className="panel ai-highlight">
          <div className="ai-icon"><Bot size={28} /></div>
          <h2>Análise inteligente</h2>
          <p>
            Com base nos dados atuais, <strong>12 alunos</strong> apresentam alto risco acadêmico.
          </p>
          <button className="btn btn-primary">Ver análise da IA</button>
        </section>
      </div>
    </DashboardLayout>
  )
}
