import { Pencil, Plus, Search } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'
import { disciplinas } from '../../data/mock'

export default function Disciplinas() {
  return (
    <DashboardLayout role="admin" title="Disciplinas" subtitle="Gerencie as disciplinas do sistema.">
      <section className="panel">
        <div className="toolbar">
          <div className="search-box"><Search size={18} /><input placeholder="Buscar por nome ou código..." /></div>
          <button className="btn btn-primary"><Plus size={18} /> Nova disciplina</button>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Nome</th><th>Código</th><th>Carga horária</th><th>Professor</th><th>Ações</th></tr></thead>
            <tbody>
              {disciplinas.map((d) => (
                <tr key={d.codigo}>
                  <td><strong>{d.nome}</strong></td><td>{d.codigo}</td><td>{d.carga}</td><td>{d.professor}</td>
                  <td className="actions"><button><Pencil size={16}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  )
}
