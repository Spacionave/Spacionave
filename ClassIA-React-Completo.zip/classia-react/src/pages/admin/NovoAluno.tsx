import { Link } from 'react-router-dom'
import DashboardLayout from '../../layouts/DashboardLayout'

export default function NovoAluno() {
  return (
    <DashboardLayout role="admin" title="Cadastrar aluno" subtitle="Preencha os dados do novo aluno.">
      <section className="panel form-panel">
        <div className="form-grid">
          <label>Nome completo<input placeholder="Digite o nome completo" /></label>
          <label>RA<input placeholder="Digite o RA" /></label>
          <label>E-mail<input type="email" placeholder="Digite o e-mail" /></label>
          <label>Data de nascimento<input type="date" /></label>
          <label>Turma
            <select><option>Selecione a turma</option><option>ADS 3A</option><option>ADS 3B</option></select>
          </label>
          <label>Senha inicial<input type="password" placeholder="Digite a senha inicial" /></label>
        </div>
        <div className="form-actions">
          <Link to="/admin/alunos" className="btn btn-secondary">Cancelar</Link>
          <button className="btn btn-primary" onClick={() => alert('Aluno salvo! (demonstração)')}>Salvar aluno</button>
        </div>
      </section>
    </DashboardLayout>
  )
}
