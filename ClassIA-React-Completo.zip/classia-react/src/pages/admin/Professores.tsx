import { Eye, Pencil, Plus, Search } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'
import { professores } from '../../data/mock'

export default function Professores() {
  return (
    <DashboardLayout role="admin" title="Professores" subtitle="Gerencie os professores cadastrados.">
      <section className="panel">
        <div className="toolbar">
          <div className="search-box"><Search size={18} /><input placeholder="Buscar por nome ou e-mail..." /></div>
          <button className="btn btn-primary"><Plus size={18} /> Novo professor</button>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Nome</th><th>E-mail</th><th>Disciplina</th><th>Turma</th><th>Ações</th></tr></thead>
            <tbody>
              {professores.map((p) => (
                <tr key={p.email}>
                  <td><strong>{p.nome}</strong></td><td>{p.email}</td><td>{p.disciplina}</td><td>{p.turma}</td>
                  <td className="actions"><button><Eye size={16}/></button><button><Pencil size={16}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  )
}
