import { BookOpen, School, UserRound, Users } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'

const turmas = [
  { nome: 'ADS 3A', alunos: 35, disciplinas: 6, professores: 4 },
  { nome: 'ADS 3B', alunos: 32, disciplinas: 6, professores: 4 },
  { nome: 'ADS 2A', alunos: 38, disciplinas: 7, professores: 5 },
]

export default function Turmas() {
  return (
    <DashboardLayout role="admin" title="Turmas" subtitle="Gerencie turmas e visualize seus detalhes.">
      <div className="cards-grid">
        {turmas.map((t) => (
          <section className="panel class-card" key={t.nome}>
            <div className="class-title"><School size={22}/><h2>{t.nome}</h2></div>
            <p><Users size={17}/> {t.alunos} alunos</p>
            <p><BookOpen size={17}/> {t.disciplinas} disciplinas</p>
            <p><UserRound size={17}/> {t.professores} professores responsáveis</p>
            <button className="btn btn-soft btn-full">Ver detalhes</button>
          </section>
        ))}
      </div>
    </DashboardLayout>
  )
}
