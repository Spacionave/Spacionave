import { Bot, Sparkles } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'

export default function AnaliseIA() {
  return (
    <DashboardLayout role="aluno" title="Análise por Inteligência Artificial" subtitle="Receba uma análise orientativa com base em suas notas e frequência.">
      <section className="panel ai-result">
        <div className="ai-result-header">
          <div className="ai-icon"><Sparkles size={24}/></div>
          <div>
            <h2>Análise do ClassIA</h2>
            <p>Baseada nos indicadores acadêmicos atuais.</p>
          </div>
          <span className="badge warning">Nível moderado</span>
        </div>

        <p>
          Você apresenta desempenho geral regular, porém possui dificuldade em
          <strong> Engenharia de Software</strong>. Sua média atual é 5,5 e sua frequência está próxima do limite mínimo.
        </p>

        <h3>Recomendações</h3>
        <ul>
          <li>Priorizar os estudos de Engenharia de Software.</li>
          <li>Revisar os conteúdos das últimas avaliações.</li>
          <li>Evitar novas faltas na disciplina.</li>
          <li>Procurar o professor para orientação.</li>
        </ul>

        <div className="ai-note">
          <Bot size={18}/>
          <span>Análise gerada por Inteligência Artificial. As informações são orientativas e não substituem a avaliação do professor ou da instituição.</span>
        </div>
      </section>
    </DashboardLayout>
  )
}
