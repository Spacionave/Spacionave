import { BookOpen, ChartNoAxesCombined, ClipboardCheck } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'
import StatCard from '../../components/StatCard'

export default function DashboardAluno() {
  return (
    <DashboardLayout role="aluno" title="Olá, João! 👋" subtitle="Disciplina hoje, conquistas amanhã.">
      <div className="stats-grid professor-grid">
        <StatCard label="Média geral" value="7,6" icon={<ChartNoAxesCombined size={22}/>} />
        <StatCard label="Frequência geral" value="87%" icon={<ClipboardCheck size={22}/>} tone="green" />
        <StatCard label="Disciplinas" value="6" icon={<BookOpen size={22}/>} tone="purple" />
      </div>

      <section className="panel">
        <div className="section-title"><div><h2>Minhas disciplinas</h2><p>Resumo das médias atuais.</p></div></div>
        <div className="subject-list">
          <div><span>Banco de Dados</span><strong className="good">8,0</strong></div>
          <div><span>Engenharia de Software</span><strong className="attention">5,5</strong></div>
          <div><span>Programação Web</span><strong className="good">8,5</strong></div>
          <div><span>Redes de Computadores</span><strong>7,0</strong></div>
        </div>
      </section>
    </DashboardLayout>
  )
}
