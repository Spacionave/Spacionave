import DashboardLayout from '../../layouts/DashboardLayout'
import { frequencias, notas } from '../../data/mock'

export default function MeuDesempenho() {
  return (
    <DashboardLayout role="aluno" title="Meu desempenho" subtitle="Visualize notas e frequência em conjunto.">
      <div className="summary-banner">
        <div><span>Média geral</span><strong>7,2</strong></div>
        <div><span>Frequência</span><strong>81%</strong></div>
        <div><span>Situação</span><strong>Regular</strong></div>
      </div>

      <section className="panel">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Disciplina</th><th>Média</th><th>Frequência</th><th>Status</th></tr></thead>
            <tbody>
              {notas.map((n) => {
                const f = frequencias.find(x => x.disciplina === n.disciplina)?.percentual ?? 0
                const ok = n.media >= 6 && f >= 75
                return (
                  <tr key={n.disciplina}>
                    <td><strong>{n.disciplina}</strong></td><td>{n.media.toFixed(1)}</td><td>{f}%</td>
                    <td><span className={`badge ${ok ? 'success' : 'warning'}`}>{ok ? 'Bom' : 'Atenção'}</span></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  )
}
