import DashboardLayout from '../../layouts/DashboardLayout'
import { frequencias } from '../../data/mock'

export default function MinhaFrequencia() {
  return (
    <DashboardLayout role="aluno" title="Minha frequência" subtitle="Acompanhe sua presença nas disciplinas.">
      <div className="cards-grid">
        {frequencias.map((f) => (
          <section className="panel frequency-card" key={f.disciplina}>
            <h3>{f.disciplina}</h3>
            <strong className={f.percentual < 75 ? 'danger-text' : ''}>{f.percentual}%</strong>
            <div className="progress"><span style={{width: `${f.percentual}%`}} /></div>
            <p>{f.percentual < 75 ? 'Atenção: abaixo de 75%' : 'Frequência adequada'}</p>
          </section>
        ))}
      </div>
    </DashboardLayout>
  )
}
