import DashboardLayout from '../../layouts/DashboardLayout'
import { notas } from '../../data/mock'

export default function MinhasNotas() {
  return (
    <DashboardLayout role="aluno" title="Minhas notas" subtitle="Consulte suas notas por disciplina.">
      <section className="panel">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Disciplina</th><th>P1</th><th>P2</th><th>Média</th><th>Situação</th></tr></thead>
            <tbody>
              {notas.map((n) => (
                <tr key={n.disciplina}>
                  <td><strong>{n.disciplina}</strong></td><td>{n.p1.toFixed(1)}</td><td>{n.p2.toFixed(1)}</td>
                  <td><strong>{n.media.toFixed(2)}</strong></td>
                  <td><span className={`badge ${n.media >= 6 ? 'success' : 'warning'}`}>{n.media >= 6 ? 'Regular' : 'Atenção'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  )
}
