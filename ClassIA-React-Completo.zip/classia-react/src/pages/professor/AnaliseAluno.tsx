import { Bot, TriangleAlert } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'

export default function AnaliseAluno() {
  return (
    <DashboardLayout role="professor" title="Análise dos alunos" subtitle="Use indicadores acadêmicos como apoio ao acompanhamento.">
      <section className="panel">
        <div className="filters-row">
          <label>Turma<select><option>ADS 3A</option></select></label>
          <label>Aluno<select><option>Maria Souza</option><option>João Silva</option></select></label>
          <button className="btn btn-primary align-end"><Bot size={18}/> Analisar desempenho</button>
        </div>
      </section>

      <section className="panel ai-result">
        <div className="ai-result-header">
          <div className="ai-icon"><Bot size={24}/></div>
          <div><h2>Resultado da análise</h2><p>Aluno: Maria Souza</p></div>
          <span className="badge warning">Risco moderado</span>
        </div>
        <div className="callout warning-box"><TriangleAlert size={20}/><span>Atenção para média abaixo de 6 e frequência próxima do limite mínimo.</span></div>
        <h3>Principais fatores</h3>
        <ul>
          <li>Média 5,5 em Engenharia de Software.</li>
          <li>Frequência geral de 76%.</li>
          <li>Queda de desempenho nas últimas avaliações.</li>
        </ul>
        <h3>Recomendação</h3>
        <p>Recomenda-se acompanhamento do desempenho nas próximas avaliações e orientação acadêmica.</p>
      </section>
    </DashboardLayout>
  )
}
