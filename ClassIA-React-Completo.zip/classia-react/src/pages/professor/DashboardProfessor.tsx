import { CalendarDays, ClipboardCheck, Users } from 'lucide-react'
import DashboardLayout from '../../layouts/DashboardLayout'
import StatCard from '../../components/StatCard'

export default function DashboardProfessor() {
  return (
    <DashboardLayout role="professor" title="Olá, Professor João! 👋" subtitle="Veja um resumo das suas turmas e atividades.">
      <div className="stats-grid professor-grid">
        <StatCard label="Minhas turmas" value="3" icon={<CalendarDays size={22}/>} tone="green" />
        <StatCard label="Alunos" value="82" icon={<Users size={22}/>} tone="purple" />
        <StatCard label="Avaliações cadastradas" value="12" icon={<ClipboardCheck size={22}/>} />
      </div>

      <section className="panel">
        <div className="section-title"><div><h2>Próximas atividades</h2><p>Compromissos das suas turmas.</p></div></div>
        <div className="activity-list">
          <div><strong>ADS 3A · Banco de Dados</strong><span>Lançamento de notas · Hoje, 19:00</span></div>
          <div><strong>ADS 3B · Banco de Dados</strong><span>Registrar frequência · Amanhã, 19:00</span></div>
          <div><strong>ADS 3A · Banco de Dados</strong><span>Reunião de turma · 16/09/2026, 19:00</span></div>
        </div>
      </section>
    </DashboardLayout>
  )
}
