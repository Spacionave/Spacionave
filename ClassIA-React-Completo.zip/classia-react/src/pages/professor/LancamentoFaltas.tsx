import { useState } from 'react'
import DashboardLayout from '../../layouts/DashboardLayout'

const nomes = ['João Silva', 'Maria Souza', 'Lucas Lima', 'Ana Beatriz']

export default function LancamentoFaltas() {
  const [presencas, setPresencas] = useState<Record<string, boolean>>({
    'João Silva': true, 'Maria Souza': false, 'Lucas Lima': true, 'Ana Beatriz': true
  })

  return (
    <DashboardLayout role="professor" title="Lançamento de faltas" subtitle="Registre a presença dos alunos.">
      <section className="panel">
        <div className="filters-row">
          <label>Turma<select><option>ADS 3A</option></select></label>
          <label>Disciplina<select><option>Banco de Dados</option></select></label>
          <label>Data<input type="date" defaultValue="2026-09-14" /></label>
        </div>

        <div className="table-wrap">
          <table>
            <thead><tr><th>Aluno</th><th>Presente</th><th>Ausente</th></tr></thead>
            <tbody>
              {nomes.map((nome) => (
                <tr key={nome}>
                  <td><strong>{nome}</strong></td>
                  <td><input type="radio" name={nome} checked={!!presencas[nome]} onChange={() => setPresencas({...presencas, [nome]: true})}/></td>
                  <td><input type="radio" name={nome} checked={!presencas[nome]} onChange={() => setPresencas({...presencas, [nome]: false})}/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="form-actions"><button className="btn btn-primary" onClick={() => alert('Chamada salva!')}>Salvar chamada</button></div>
      </section>
    </DashboardLayout>
  )
}
