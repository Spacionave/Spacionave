import { useState } from 'react'
import DashboardLayout from '../../layouts/DashboardLayout'

const iniciais = [
  { aluno: 'João Silva', nota: 8.5 },
  { aluno: 'Maria Souza', nota: 5.0 },
  { aluno: 'Lucas Lima', nota: 7.5 },
  { aluno: 'Ana Beatriz', nota: 9.0 },
]

export default function LancamentoNotas() {
  const [dados, setDados] = useState(iniciais)

  return (
    <DashboardLayout role="professor" title="Lançamento de notas" subtitle="Registre as notas da turma selecionada.">
      <section className="panel">
        <div className="filters-row">
          <label>Turma<select><option>ADS 3A</option><option>ADS 3B</option></select></label>
          <label>Disciplina<select><option>Banco de Dados</option></select></label>
          <label>Avaliação<select><option>Prova 1</option><option>Prova 2</option></select></label>
        </div>

        <div className="table-wrap">
          <table>
            <thead><tr><th>Aluno</th><th>Nota</th></tr></thead>
            <tbody>
              {dados.map((item, index) => (
                <tr key={item.aluno}>
                  <td><strong>{item.aluno}</strong></td>
                  <td>
                    <input className="score-input" type="number" min="0" max="10" step="0.1"
                      value={item.nota}
                      onChange={(e) => {
                        const clone = [...dados]
                        clone[index] = { ...clone[index], nota: Number(e.target.value) }
                        setDados(clone)
                      }}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="form-actions"><button className="btn btn-secondary">Cancelar</button><button className="btn btn-primary" onClick={() => alert('Notas salvas!')}>Salvar notas</button></div>
      </section>
    </DashboardLayout>
  )
}
